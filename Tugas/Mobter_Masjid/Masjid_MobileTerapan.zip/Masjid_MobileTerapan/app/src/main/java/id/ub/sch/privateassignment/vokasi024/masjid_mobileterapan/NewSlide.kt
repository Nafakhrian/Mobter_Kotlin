package id.ub.sch.privateassignment.vokasi024.masjid_mobileterapan

class NewSlide(val judul:String, val url: String)