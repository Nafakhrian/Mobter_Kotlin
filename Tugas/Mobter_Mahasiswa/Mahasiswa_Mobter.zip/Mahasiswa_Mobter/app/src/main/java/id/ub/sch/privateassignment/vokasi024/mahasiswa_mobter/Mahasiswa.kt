package id.ub.sch.privateassignment.vokasi024.mahasiswa_mobter

data class Mahasiswa (
    val nama:String,
    val nomor:String,
    val alamat:String)